const express = require('express');
const router = express.Router();
const Cart = require('../models/cart');
const Product = require('../models/product');

// Create a new empty cart
router.post('/', async (req, res) => {
  try {
    const cart = new Cart({ items: [] });
    await cart.save();
    res.status(201).json(cart);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Get cart by id
router.get('/:id', async (req, res) => {
  try {
    const cart = await Cart.findById(req.params.id).populate('items.product');
    if (!cart) return res.status(404).json({ error: 'Cart not found' });
    res.json(cart);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Add item to cart
router.post('/:id/items', async (req, res) => {
  try {
    const { productId, quantity } = req.body;
    const cart = await Cart.findById(req.params.id);
    if (!cart) return res.status(404).json({ error: 'Cart not found' });
    const product = await Product.findById(productId);
    if (!product) return res.status(404).json({ error: 'Product not found' });

    const existing = cart.items.find(it => it.product.equals(productId));
    if (existing) existing.quantity += quantity;
    else cart.items.push({ product: productId, quantity });

    await cart.save();
    res.json(await cart.populate('items.product'));
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
