import React, { createContext, useContext, useReducer } from 'react';

const CartContext = createContext();

const initialState = { items: [] };

function reducer(state, action) {
  switch (action.type) {
    case 'ADD':
      {
        const { product, qty = 1 } = action.payload;
        const existing = state.items.find(i => i.product._id === product._id);
        if (existing) {
          return {
            ...state,
            items: state.items.map(i => i.product._id === product._id ? { ...i, quantity: i.quantity + qty } : i)
          };
        } else {
          return { ...state, items: [...state.items, { product, quantity: qty }] };
        }
      }
    case 'REMOVE':
      return { ...state, items: state.items.filter(i => i.product._id !== action.payload.productId) };
    case 'CLEAR':
      return initialState;
    default:
      return state;
  }
}

export function CartProvider({ children }) {
  const [state, dispatch] = useReducer(reducer, initialState);
  const addToCart = (product, qty) => dispatch({ type: 'ADD', payload: { product, qty }});
  const removeFromCart = (productId) => dispatch({ type: 'REMOVE', payload: { productId }});
  const clearCart = () => dispatch({ type: 'CLEAR'});

  return (
    <CartContext.Provider value={{ cart: state, addToCart, removeFromCart, clearCart }}>
      {children}
    </CartContext.Provider>
  );
}

export const useCart = () => useContext(CartContext);
