import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';

export default function ProductList() {
  const [products, setProducts] = useState([]);
  useEffect(() => {
    fetch('http://localhost:5000/api/products')
      .then(r => r.json())
      .then(setProducts)
      .catch(console.error);
  }, []);
  return (
    <div>
      <h2>Products</h2>
      <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap' }}>
        {products.map(p => (
          <div key={p._id} style={{ border: '1px solid #ddd', padding: 12, width: 220 }}>
            <img src={p.image || 'https://via.placeholder.com/200'} alt={p.title} style={{ width: '100%' }} />
            <h3>{p.title}</h3>
            <p>${p.price.toFixed(2)}</p>
            <Link to={`/product/${p._id}`}>View</Link>
          </div>
        ))}
      </div>
    </div>
  );
}
