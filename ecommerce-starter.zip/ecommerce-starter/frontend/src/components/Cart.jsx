import React from 'react';
import { useCart } from '../context/CartContext';

export default function Cart() {
  const { cart, removeFromCart, clearCart } = useCart();
  const total = cart.items.reduce((s, it) => s + it.product.price * it.quantity, 0);

  return (
    <div>
      <h2>Cart</h2>
      {cart.items.length === 0 ? <p>Your cart is empty</p> :
        <>
          <ul>
            {cart.items.map(i => (
              <li key={i.product._id}>
                {i.product.title} — {i.quantity} × ${i.product.price.toFixed(2)} 
                <button onClick={() => removeFromCart(i.product._id)}>Remove</button>
              </li>
            ))}
          </ul>
          <p><strong>Total: ${total.toFixed(2)}</strong></p>
          <button onClick={clearCart}>Clear</button>
        </>
      }
    </div>
  );
}
