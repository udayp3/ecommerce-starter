import React from 'react';
import { Link } from 'react-router-dom';
import { useCart } from '../context/CartContext';

export default function NavBar(){
  const { cart } = useCart();
  const count = cart.items.reduce((s, i) => s + i.quantity, 0);
  return (
    <nav style={{ padding: 12, borderBottom: '1px solid #ddd', display: 'flex', justifyContent: 'space-between' }}>
      <div><Link to="/">E-Shop</Link></div>
      <div>
        <Link to="/cart">Cart ({count})</Link>
      </div>
    </nav>
  );
}
